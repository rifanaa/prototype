import 'package:flutter/material.dart';

class profil extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Profil Mahasiswa'),
        backgroundColor: Colors.blue,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            isiProfil(Icons.account_circle, 'NIM', '21.230.0136'),
            isiProfil(Icons.person, 'Nama', 'Rif Ana Suryaningsih'),
            isiProfil(Icons.school, 'Program Studi', 'Sistem Informasi'),
            isiProfil(Icons.book, 'Program', 'Sarjana'),
            isiProfil(Icons.class_, 'Kelas', '7P53'),
            isiProfil(Icons.supervisor_account, 'Dosen PA',
                'Victorianus Aries Siswanto, M.Si'),
            isiProfil(Icons.home, 'Alamat',
                'Desa Pakumbulan Kec. Buaran Kab. Pekalongan'),
            SizedBox(height: 20),
            Text(
              'Tentang Saya',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 10),
            Text(
              'Saya adalah seorang mahasiswa semester tujuh yang saat ini sedang fokus terkait skripsi saya. '
              'Skripsi saya membahas mengenai sistem informasi penjualan dan stok yang ada di toko surototo.',
              style: TextStyle(fontSize: 16),
            ),
          ],
        ),
      ),
    );
  }

  Widget isiProfil(IconData icon, String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4.0),
      child: Row(
        children: [
          Icon(icon, color: Colors.blue),
          SizedBox(
            width: 10,
          ),
          Text(
            '$label:',
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
          ),
          SizedBox(width: 10),
          Flexible(
            child: Text(
              value,
              style: TextStyle(fontSize: 16),
              overflow: TextOverflow.ellipsis,
              maxLines: 2,
            ),
          ),
        ],
      ),
    );
  }
}
