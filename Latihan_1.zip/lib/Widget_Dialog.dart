import 'dart:html';

import 'package:flutter/material.dart';

class Widget_Dialog extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Latihan Dialog'),
        backgroundColor: Colors.blue,
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(
              onPressed: () {
                showDialog<String>(
                  context: context,
                  builder: (BuildContext context) => AlertDialog(
                    title: Text('Dialog Title'),
                    content: Text('Simple Alert'),
                    actions: <Widget>[
                      TextButton(
                        onPressed: () => Navigator.pop(context, 'Cancel'),
                        child: Text('Cancel'),
                      ),
                      TextButton(
                        onPressed: () => Navigator.pop(context, 'OK'),
                        child: Text('Ok'),
                      )
                    ],
                  ),
                ).then((returnVal) {
                  if (returnVal != null) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text('Kamu menekan tombol: $returnVal'),
                        action: SnackBarAction(label: 'OK', onPressed: () {}),
                      ),
                    );
                  } else {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text('Kamu menekan tombol: $returnVal'),
                        action:
                            SnackBarAction(label: 'Cancel', onPressed: () {}),
                      ),
                    );
                  }
                });
              },
              child: Text('Dialog Title'),
            ),
          ],
        ),
      ),
    );
  }
}
