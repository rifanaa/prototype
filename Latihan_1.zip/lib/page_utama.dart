import 'package:flutter/material.dart';

class Page_Utama extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Navigasi Page'),
      ),
      body: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          MaterialButton(
            color: Colors.yellow,
            child: Text('Fakultas'),
            onPressed: () {
              Navigator.of(context).pushNamed('/menu_1');
            },
          ),
        ],
      ),
    );
  }
}
