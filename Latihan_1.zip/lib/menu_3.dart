import 'package:flutter/material.dart';
import 'profil_si.dart';
import 'profil_ti.dart';
import 'profil_ka.dart';
import 'profil.mi.dart';

class Menu_3 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Fakultas'),
      ),
      body: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          MaterialButton(
            color: Colors.blue,
            child: Text('SI'),
            onPressed: () {
              Navigator.push(
                  context, MaterialPageRoute(builder: (contex) => Profil_SI()));
            },
          ),
          MaterialButton(
            color: Colors.blue,
            child: Text('TI'),
            onPressed: () {
              Navigator.push(
                  context, MaterialPageRoute(builder: (contex) => Profil_TI()));
            },
          ),
          MaterialButton(
            color: Colors.blue,
            child: Text('MI'),
            onPressed: () {
              Navigator.push(
                  context, MaterialPageRoute(builder: (contex) => Profil_MI()));
            },
          ),
          MaterialButton(
            color: Colors.blue,
            child: Text('KA'),
            onPressed: () {
              Navigator.push(
                  context, MaterialPageRoute(builder: (contex) => Profil_KA()));
            },
          ),
        ],
      ),
    );
  }
}
