import 'package:flutter/material.dart';
import 'widget_image.dart';
import 'Widget_Dialog.dart';
import 'TextFormFieldWidget.dart';

void main() {
  runApp(latihan());
}

class latihan extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Latihan gambar',
      home: widget_image(),
    );
  }
}
