import 'package:flutter/material.dart';
import 'profil.dart';

void main() {
  runApp(tugasprofil());
}

class tugasprofil extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Tugas Profil',
      home: profil(),
      debugShowCheckedModeBanner: false,
    );
  }
}
