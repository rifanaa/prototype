import 'package:flutter/material.dart';

class TugasModul extends StatelessWidget {
  const TugasModul({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    void _showSnack() {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          backgroundColor: Color(0xffe5bd45),
          content: const Text('Button tapped'),
          duration: const Duration(milliseconds: 500),
          action: SnackBarAction(
            textColor: Colors.lightBlue,
            label: "OK",
            onPressed: () {},
          ),
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.red,
        leading: const Icon(Icons.tag_faces),
        title: const Text("Tugas Modul 5"),
        actions: <Widget>[
          IconButton(
            icon: const Icon(Icons.palette),
            onPressed: () {},
          ),
          PopupMenuButton(
            itemBuilder: (BuildContext context) {
              return [
                const PopupMenuItem(child: Text('Merah')),
                const PopupMenuItem(child: Text('Kuning')),
                const PopupMenuItem(child: Text('Hijau')),
                const PopupMenuItem(child: Text('Biru')),
              ];
            },
          ),
        ],
      ),
      body: Column(
        children: [
          // Row untuk menampung tombol dan kotak teal di samping
          Row(
            children: [
              Expanded(
                flex: 2,
                child: Container(
                  height: MediaQuery.of(context).size.height * 0.56,
                  decoration: BoxDecoration(
                    // Mengatur tinggi kolom kanan sesuai tinggi layar
                    color: Colors.lightBlue[100],
                    borderRadius: BorderRadius.circular(30),
                  ),
                  padding: const EdgeInsets.all(15),
                  child: Column(
                    children: [
                      ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.yellow,
                          padding: const EdgeInsets.symmetric(
                              horizontal: 32, vertical: 16),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(20),
                          ),
                        ),
                        onPressed: _showSnack,
                        child: const Text('ElevatedButton'),
                      ),
                      Divider(
                        color: Colors.grey, // Warna garis
                        thickness: 1, // Ketebalan garis
                        height: 30, // Jarak antara Divider dengan elemen lain
                      ),
                      const SizedBox(height: 1),
                      TextButton(
                        onPressed: _showSnack,
                        child: const Text(
                          'TextButton',
                          style: TextStyle(color: Colors.purple),
                        ),
                      ),
                      Divider(
                        color: Colors.grey, // Warna garis
                        thickness: 1, // Ketebalan garis
                        height: 18, // Jarak antara Divider dengan elemen lain
                      ),
                      const SizedBox(height: 10),
                      OutlinedButton(
                        onPressed: _showSnack,
                        style: OutlinedButton.styleFrom(
                          side: const BorderSide(color: Colors.purple),
                        ),
                        child: const Text(
                          'OutlineButton',
                          style: TextStyle(color: Colors.purple),
                        ),
                      ),
                      Divider(
                        color: Colors.grey, // Warna garis
                        thickness: 1, // Ketebalan garis
                        height: 35, // Jarak antara Divider dengan elemen lain
                      ),
                      const SizedBox(height: 10),
                      Align(
                        alignment: Alignment(
                            0.0, 0.0), // Mengatur posisi vertikal ikon telepon
                        child: Icon(
                          Icons.phone,
                          size: 33,
                          color: Colors.black,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              // Container teal di sebelah kanan tombol
              Expanded(
                flex: 1,
                child: Container(
                  margin: EdgeInsets.only(right: 10.0),
                  height: MediaQuery.of(context).size.height * 0.56,
                  decoration: BoxDecoration(
                    // Mengatur tinggi kolom kanan sesuai tinggi layar
                    color: Colors.teal[900],
                    borderRadius: BorderRadius.circular(30),
                  ),
                  padding: const EdgeInsets.all(16),
                  child: Align(
                    alignment: Alignment.topLeft,
                    child: Text(
                      'STMIK Widya Pratama',
                      style: TextStyle(
                        color: Colors.black,
                        fontSize: 18,
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
          Container(
            color: Colors.yellow,
            padding: const EdgeInsets.symmetric(vertical: 45),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                IconButton(
                  icon: const Icon(Icons.call),
                  color: Colors.black,
                  onPressed: _showSnack,
                ),
                IconButton(
                  icon: const Icon(Icons.email),
                  color: Colors.black,
                  onPressed: _showSnack,
                ),
                IconButton(
                  icon: const Icon(Icons.home),
                  color: Colors.black,
                  onPressed: _showSnack,
                ),
                IconButton(
                  icon: const Icon(Icons.facebook),
                  color: Colors.black,
                  onPressed: _showSnack,
                ),
              ],
            ),
          ),
          // Kotak berwarna di bawah
          Expanded(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                isibox(Colors.cyan, "STMIK Widya Pratama"),
                isibox(Colors.green, "STMIK Widya Pratama"),
                isibox(Colors.orange, "STMIK Widya Pratama"),
                isibox(Colors.red, "STMIK Widya Pratama"),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget isibox(Color color, String text) {
    return Expanded(
      child: Container(
        margin: const EdgeInsets.all(0),
        decoration: BoxDecoration(
          color: color,
          borderRadius: BorderRadius.only(
            topLeft: Radius.circular(30),
            topRight:
                Radius.circular(30), // Hanya sudut kiri atas yang melengkung
            bottomRight:
                Radius.circular(10), // Hanya sudut kanan bawah yang melengkung
          ),
        ),
        padding: const EdgeInsets.all(15),
        child: Center(
          child: Text(
            text,
            style: const TextStyle(color: Colors.black),
            textAlign: TextAlign.center,
          ),
        ),
      ),
    );
  }
}
