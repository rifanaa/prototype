import 'package:flutter/material.dart';

void main() {
  runApp(latihan_child());
}

class latihan_child extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: Text(
            "Latihan Child",
            style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
          ),
          backgroundColor: Color(0xff135389),
        ),
        body: Container(
          child: Text("selamat datang"),
          margin: EdgeInsets.all(100),
          padding: EdgeInsets.all(16.0),
          color: Colors.blue,
        ),
      ),
    );
  }
}
