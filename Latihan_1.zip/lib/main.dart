import 'package:flutter/material.dart';
import 'page_utama.dart';
import 'menu_1.dart';
import 'menu_2.dart';

void main() {
  runApp(Navigasi_Page());
}

class Navigasi_Page extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Navigasi Page',
      debugShowCheckedModeBanner: false,
      home: Page_Utama(),
      routes: {
        '/menu_1': (BuildContext context) => Menu_1(),
      },
    );
  }
}
