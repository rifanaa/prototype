import 'package:flutter/material.dart';

class TextFormFieldWidget extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Latihan Form Text Field'),
        backgroundColor: Colors.blue,
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: EdgeInsets.all(10.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              TextFormField(
                decoration: InputDecoration(
                  border: UnderlineInputBorder(),
                  filled: true,
                  prefixIcon: Icon(Icons.person_2),
                  hintText: 'Tuliskan Nama Lengkap',
                  labelText: 'Nama *',
                ),
              ),
              SizedBox(height: 15),
              TextFormField(
                keyboardType: TextInputType.phone,
                decoration: InputDecoration(
                  border: UnderlineInputBorder(),
                  filled: true,
                  prefixIcon: Icon(Icons.phone),
                  hintText: 'Tuliskan Nomor Telepon',
                  labelText: 'Nomor Telepon *',
                  prefixText: '+62',
                ),
              ),
              SizedBox(height: 15),
              TextFormField(
                keyboardType: TextInputType.emailAddress,
                decoration: InputDecoration(
                  border: UnderlineInputBorder(),
                  filled: true,
                  prefixIcon: Icon(Icons.email),
                  hintText: 'Your Email Address',
                  labelText: 'E-mail',
                ),
              ),
              SizedBox(height: 15),
              TextFormField(
                maxLines: 3,
                decoration: InputDecoration(
                  border: OutlineInputBorder(),
                  hintText: 'Ceritakan tentang dirimu',
                  labelText: 'Life Story',
                ),
              ),
              SizedBox(height: 15),
              TextFormField(
                decoration: InputDecoration(
                  border: OutlineInputBorder(),
                  labelText: 'Salary',
                  prefixText: '\Rp.',
                  suffixText: 'Rupiah',
                  suffixStyle: TextStyle(color: Colors.green),
                ),
              ),
              SizedBox(height: 24.0),
              TextFormField(
                obscureText: true,
                maxLength: 8,
                decoration: InputDecoration(
                  border: OutlineInputBorder(),
                  labelText: 'Password',
                  filled: true,
                  suffixIcon: Icon(Icons.visibility),
                ),
              ),
              SizedBox(height: 15),
            ],
          ),
        ),
      ),
    );
  }
}
