import 'package:flutter/material.dart';

void main() {
  runApp(coba_children());
}

class coba_children extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: Text(
            'Latihan Children',
          ),
          backgroundColor: Colors.yellow,
        ),
        body: Row(
          children: <Widget>[
            Expanded(
              child: Column(
                children: [
                  _isi_container(label: 'BIRU', color: Colors.blue),
                  _isi_container(label: 'KUNING', color: Colors.yellow),
                  _isi_container(label: 'PUTIH', color: Colors.white)
                ],
              ),
            ),
            Expanded(
              child: Column(
                children: [
                  _isi_container(label: 'HIJAU', color: Colors.green),
                  _isi_container(label: 'MERAH', color: Colors.red),
                  _isi_container(label: 'UNGU', color: Colors.purple)
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _isi_container({required String label, required Color color}) {
    return Expanded(
      child: Container(
        child: Center(child: Text(label)),
        color: color,
        padding: EdgeInsets.all(20),
      ),
    );
  }
}
