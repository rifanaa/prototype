import 'package:flutter/material.dart';

import 'TugasModul.dart';

void main() {
  runApp(Tugas());
}

class Tugas extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Tugas Modul 5',
      home: TugasModul(),
      debugShowCheckedModeBanner: false,
    );
  }
}
