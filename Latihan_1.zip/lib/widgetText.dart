import 'package:flutter/material.dart';

class widgetText extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    //disini tidak menggunakan materialapp(tempat conten) dikarenakan ini adalah class widget yang digunakan untuk memberikan isi conten(spt:appbar) yang akan dimasukkan ke dalam latihantxt
    return Scaffold(
      appBar: AppBar(
        title: Text('Text Widget'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(10),
        child: Text(
          "Selamat datang di kampus Institut Widya Pratama yang berada di kota Pekalongan desa jeruk sari",
          maxLines: 10,
          overflow: TextOverflow.ellipsis,
          textAlign: TextAlign.center,
          style: TextStyle(
            color: Colors.black,
            fontFamily: 'Happy Spring',
            fontStyle: FontStyle.italic,
            fontWeight: FontWeight.bold,
            fontSize: 24,
            backgroundColor: Colors.grey,
            decoration: TextDecoration.underline,
          ),
        ),
      ),
    );
  }
}
