import 'package:flutter/material.dart';
import 'menu_2.dart';
import 'menu_3.dart';

class Menu_1 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Fakultas'),
      ),
      body: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          MaterialButton(
            color: Colors.yellow,
            child: Text('Kembali '),
            onPressed: () {
              Navigator.pop(context);
            },
          ),
          MaterialButton(
            color: Colors.blue,
            child: Text('FEB'),
            onPressed: () {
              Navigator.push(
                  context, MaterialPageRoute(builder: (contex) => Menu_2()));
            },
          ),
          MaterialButton(
            color: Colors.green,
            child: Text('FTIK'),
            onPressed: () {
              Navigator.push(
                  context, MaterialPageRoute(builder: (contex) => Menu_3()));
            },
          )
        ],
      ),
    );
  }
}
