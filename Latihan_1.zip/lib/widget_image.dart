import 'package:flutter/material.dart';

class widget_image extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Latihan Widget Image'),
      ),
      body: ListView(
        padding: EdgeInsets.all(8),
        children: [
          ListTile(
            leading: Icon(Icons.access_alarm),
            title: Text('Image dari Assets'),
            trailing: Icon(Icons.arrow_forward),
          ),
          Card(
            child: Image.asset('assets/gambar/profil.png'),
          )
        ],
      ),
    );
  }
}
