import 'package:flutter/material.dart';
import 'profil_bd.dart';

class Menu_2 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('FEB'),
      ),
      body: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          MaterialButton(
            color: Colors.yellow,
            child: Text('Kembali'),
            onPressed: () {
              Navigator.pop(context);
            },
          ),
          MaterialButton(
            color: Colors.blue,
            child: Text('Bisnis Digital'),
            onPressed: () {
              Navigator.push(
                  context, MaterialPageRoute(builder: (contex) => Profil_BD()));
            },
          )
        ],
      ),
    );
  }
}
